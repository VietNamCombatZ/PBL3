package model;

public enum trangThaiDatSan {
    CHO_THANH_TOAN,
    DA_THANH_TOAN,
    DA_HUY;

}
