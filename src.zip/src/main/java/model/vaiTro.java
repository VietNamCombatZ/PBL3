package model;

public enum vaiTro {
    QUAN_LY,
    NHAN_VIEN,
    KHACH_HANG;
}
