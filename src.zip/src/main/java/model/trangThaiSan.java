package model;

public enum trangThaiSan {
    HOAT_DONG,
    BAO_TRI
}
