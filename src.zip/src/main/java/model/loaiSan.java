package model;

public enum loaiSan {
    SAN_5,
    SAN_7
}
