package model;

public enum loaiCongViec {
    BAO_TRI_SAN,
    THU_NGAN,
    VE_SINH


}
