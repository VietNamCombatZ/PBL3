package model;

public enum mucDiem {
    RAT_TICH_CUC,
    TICH_CUC,
    TRUNG_BINH,
    TIEU_CUC,
    RAT_TIEU_CUC
}
